package com.example.Adapter;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class Description extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);
    }
}